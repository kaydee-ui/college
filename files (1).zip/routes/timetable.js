const express = require('express');
const Timetable = require('../models/Timetable');
const router = express.Router();

// List all timetable entries (optionally filter by className or day)
router.get('/', async (req, res) => {
    const { className, day } = req.query;
    let query = {};
    if (className) query.className = className;
    if (day) query.day = day;
    try {
        const entries = await Timetable.find(query).sort({ day: 1, startTime: 1 });
        res.json(entries);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a timetable entry
router.post('/', async (req, res) => {
    try {
        const entry = new Timetable(req.body);
        await entry.save();
        res.status(201).json(entry);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a timetable entry
router.delete('/:id', async (req, res) => {
    try {
        await Timetable.findByIdAndDelete(req.params.id);
        res.json({ message: 'Timetable entry deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;