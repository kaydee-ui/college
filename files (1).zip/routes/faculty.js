const express = require('express');
const router = express.Router();
const Faculty = require('../models/Faculty');

// Similar CRUD routes as 'student.js' (Get All, Add, Get One, Update, Delete)

module.exports = router;