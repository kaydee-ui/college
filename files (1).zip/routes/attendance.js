const express = require('express');
const Attendance = require('../models/Attendance');
const router = express.Router();

// Mark attendance
router.post('/', async (req, res) => {
    try {
        const { studentId, date, status, subject, markedBy } = req.body;
        const attendance = new Attendance({ studentId, date, status, subject, markedBy });
        await attendance.save();
        res.status(201).json(attendance);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get attendance for a student
router.get('/student/:studentId', async (req, res) => {
    try {
        const data = await Attendance.find({ studentId: req.params.studentId }).sort({ date: -1 });
        res.json(data);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get attendance summary for a class/subject
router.get('/summary', async (req, res) => {
    const { subject } = req.query;
    try {
        const summary = await Attendance.aggregate([
            ...(subject ? [{ $match: { subject } }] : []),
            { $group: { _id: "$status", count: { $sum: 1 } } }
        ]);
        res.json(summary);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;