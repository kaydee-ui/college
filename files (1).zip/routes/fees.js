const express = require('express');
const Fee = require('../models/Fee');
const router = express.Router();

// List all fees (optionally by student)
router.get('/', async (req, res) => {
    const { studentId } = req.query;
    const query = studentId ? { studentId } : {};
    try {
        const fees = await Fee.find(query).populate('studentId');
        res.json(fees);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a new fee record
router.post('/', async (req, res) => {
    try {
        const fee = new Fee(req.body);
        await fee.save();
        res.status(201).json(fee);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Mark fee as paid
router.put('/:id/pay', async (req, res) => {
    try {
        const fee = await Fee.findById(req.params.id);
        if (!fee) return res.status(404).json({ message: 'Fee record not found' });
        fee.paid = true;
        fee.paidOn = new Date();
        await fee.save();
        res.json(fee);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a fee record
router.delete('/:id', async (req, res) => {
    try {
        await Fee.findByIdAndDelete(req.params.id);
        res.json({ message: 'Fee record deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;