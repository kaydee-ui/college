const express = require('express');
const Alumni = require('../models/Alumni');
const router = express.Router();

// Get all alumni
router.get('/', async (req, res) => {
    try {
        const alumni = await Alumni.find();
        res.json(alumni);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a new alumni
router.post('/', async (req, res) => {
    const { name, email, yearOfGraduation, currentEmployment, achievements } = req.body;
    const alumni = new Alumni({ name, email, yearOfGraduation, currentEmployment, achievements });
    try {
        const newAlumni = await alumni.save();
        res.status(201).json(newAlumni);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update an alumni
router.put('/:id', async (req, res) => {
    try {
        const updatedAlumni = await Alumni.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedAlumni);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete an alumni
router.delete('/:id', async (req, res) => {
    try {
        await Alumni.findByIdAndDelete(req.params.id);
        res.json({ message: 'Alumni deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;