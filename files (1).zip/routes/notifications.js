const express = require('express');
const Notification = require('../models/Notification');
const router = express.Router();

// Get all notifications (optionally filter by user)
router.get('/', async (req, res) => {
    const { userId } = req.query;
    let query = {};
    if (userId) query.targetUsers = userId;
    try {
        const notifications = await Notification.find(query).sort({ createdAt: -1 });
        res.json(notifications);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Create a new notification
router.post('/', async (req, res) => {
    const { title, message, targetUsers } = req.body;
    const notification = new Notification({ title, message, targetUsers });
    try {
        const saved = await notification.save();
        res.status(201).json(saved);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Mark as read
router.put('/:id/read', async (req, res) => {
    try {
        const updated = await Notification.findByIdAndUpdate(
            req.params.id,
            { isRead: true },
            { new: true }
        );
        res.json(updated);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete notification
router.delete('/:id', async (req, res) => {
    try {
        await Notification.findByIdAndDelete(req.params.id);
        res.json({ message: 'Notification deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;