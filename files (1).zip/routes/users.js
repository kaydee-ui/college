const express = require('express');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const { authMiddleware, roleMiddleware } = require('../middleware/auth');
const router = express.Router();

// Register a user (admin only)
router.post('/register', authMiddleware, roleMiddleware('admin'), async (req, res) => {
    const { username, password, role } = req.body;
    const user = new User({ username, password, role });
    try {
        const saved = await user.save();
        res.status(201).json(saved);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Login
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user || user.password !== password) { // Use bcrypt in real code!
        return res.status(400).json({ message: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user._id, role: user.role }, 'SECRET', { expiresIn: '1d' });
    res.json({ token, user: { username: user.username, role: user.role } });
});

// Get current user info
router.get('/me', authMiddleware, (req, res) => {
    res.json(req.user);
});

module.exports = router;