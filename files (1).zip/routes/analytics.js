const express = require('express');
const Student = require('../models/Student');
const Alumni = require('../models/Alumni');
const Book = require('../models/Book');
const Transaction = require('../models/Transaction');
const Placement = require('../models/Placement');
const router = express.Router();

// Dashboard summary
router.get('/summary', async (req, res) => {
    try {
        const studentCount = await Student.countDocuments();
        const alumniCount = await Alumni.countDocuments();
        const bookCount = await Book.countDocuments();
        const issuedBooks = await Book.countDocuments({ status: 'issued' });
        const availableBooks = await Book.countDocuments({ status: 'available' });
        const placementCount = await Placement.countDocuments();

        res.json({
            studentCount,
            alumniCount,
            bookCount,
            issuedBooks,
            availableBooks,
            placementCount
        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Placements by company
router.get('/placements-by-company', async (req, res) => {
    try {
        const data = await Placement.aggregate([
            { $group: { _id: "$companyName", count: { $sum: 1 } } },
            { $sort: { count: -1 } }
        ]);
        res.json(data);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Books issued by student
router.get('/books-issued', async (req, res) => {
    try {
        const data = await Transaction.aggregate([
            { $group: { _id: "$studentId", issued: { $sum: 1 } } },
            { $sort: { issued: -1 } }
        ]);
        res.json(data);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;