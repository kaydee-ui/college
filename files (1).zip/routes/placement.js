const express = require('express');
const Placement = require('../models/Placement');
const router = express.Router();

// Get all placements
router.get('/', async (req, res) => {
    try {
        const data = await Placement.find().populate('studentId');
        res.json(data);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a new placement record
router.post('/', async (req, res) => {
    const placement = new Placement(req.body);
    try {
        const newPlacement = await placement.save();
        res.status(201).json(newPlacement);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update a placement
router.put('/:id', async (req, res) => {
    try {
        const updated = await Placement.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updated);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a placement record
router.delete('/:id', async (req, res) => {
    try {
        await Placement.findByIdAndDelete(req.params.id);
        res.json({ message: 'Placement deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;