const express = require('express');
const Exam = require('../models/Exam');
const router = express.Router();

// List all exams (optionally filter by class or subject)
router.get('/', async (req, res) => {
    const { className, subject } = req.query;
    let query = {};
    if (className) query.className = className;
    if (subject) query.subject = subject;
    try {
        const exams = await Exam.find(query).sort({ examDate: 1, startTime: 1 });
        res.json(exams);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add an exam
router.post('/', async (req, res) => {
    try {
        const exam = new Exam(req.body);
        await exam.save();
        res.status(201).json(exam);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete an exam
router.delete('/:id', async (req, res) => {
    try {
        await Exam.findByIdAndDelete(req.params.id);
        res.json({ message: 'Exam deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;