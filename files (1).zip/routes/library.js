const express = require('express');
const Book = require('../models/Book');
const Transaction = require('../models/Transaction');
const router = express.Router();

// Get all books
router.get('/books', async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a new book
router.post('/books', async (req, res) => {
    const { title, author, ISBN } = req.body;
    const book = new Book({ title, author, ISBN });
    try {
        const newBook = await book.save();
        res.status(201).json(newBook);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Issue a book
router.post('/transactions', async (req, res) => {
    const { studentId, bookId } = req.body;
    try {
        const book = await Book.findById(bookId);
        if (!book || book.status === 'issued') {
            return res.status(400).json({ message: 'Book is not available' });
        }

        const transaction = new Transaction({ studentId, bookId });
        await transaction.save();

        book.status = 'issued';
        await book.save();

        res.status(201).json(transaction);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Return a book
router.put('/transactions/:id/return', async (req, res) => {
    try {
        const transaction = await Transaction.findById(req.params.id);
        if (!transaction) return res.status(404).json({ message: 'Transaction not found' });

        transaction.returnDate = new Date();
        const book = await Book.findById(transaction.bookId);
        book.status = 'available';

        await transaction.save();
        await book.save();

        res.json(transaction);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get all transactions
router.get('/transactions', async (req, res) => {
    try {
        const transactions = await Transaction.find().populate('bookId studentId');
        res.json(transactions);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;