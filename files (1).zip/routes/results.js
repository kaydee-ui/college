const express = require('express');
const Result = require('../models/Result');
const roles = require('../middleware/role');
const router = express.Router();
const json2csv = require('json2csv').parse; // npm install json2csv

// Helper function for grade calculation
function calculateGrade(marks, total) {
    const percent = (marks / total) * 100;
    if (percent >= 90) return "A+";
    if (percent >= 80) return "A";
    if (percent >= 70) return "B";
    if (percent >= 60) return "C";
    if (percent >= 50) return "D";
    return "F";
}

// List all results (with filtering)
router.get('/', async (req, res) => {
    const { studentId, examId } = req.query;
    let query = {};
    if (studentId) query.studentId = studentId;
    if (examId) query.examId = examId;
    try {
        const results = await Result.find(query).populate('studentId examId');
        res.json(results);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// List results for current student only
router.get('/my', async (req, res) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
    let query = { studentId: req.user._id };
    try {
        const results = await Result.find(query).populate('studentId examId');
        res.json(results);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Export results to CSV (admin/faculty only)
router.get('/export', roles('admin', 'faculty'), async (req, res) => {
    const { studentId, examId } = req.query;
    let query = {};
    if (studentId) query.studentId = studentId;
    if (examId) query.examId = examId;
    try {
        const results = await Result.find(query).populate('studentId examId');
        const csv = json2csv(results.map(r => ({
            student: r.studentId?.name || r.studentId,
            exam: r.examId?.title || r.examId,
            subject: r.subject,
            marksObtained: r.marksObtained,
            totalMarks: r.totalMarks,
            grade: r.grade,
            remarks: r.remarks
        })));
        res.header('Content-Type', 'text/csv');
        res.attachment('results.csv');
        return res.send(csv);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a result (admin/faculty only, auto-grade)
router.post('/', roles('admin', 'faculty'), async (req, res) => {
    try {
        let { studentId, examId, subject, marksObtained, totalMarks, remarks } = req.body;
        marksObtained = Number(marksObtained);
        totalMarks = Number(totalMarks);
        const grade = calculateGrade(marksObtained, totalMarks);
        const result = new Result({ studentId, examId, subject, marksObtained, totalMarks, grade, remarks });
        await result.save();
        res.status(201).json(result);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a result (admin/faculty only)
router.delete('/:id', roles('admin', 'faculty'), async (req, res) => {
    try {
        await Result.findByIdAndDelete(req.params.id);
        res.json({ message: 'Result deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;