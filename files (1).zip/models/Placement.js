const mongoose = require('mongoose');

const PlacementSchema = new mongoose.Schema({
    studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    companyName: { type: String, required: true },
    position: { type: String, required: true },
    salary: { type: Number },
    status: { type: String, enum: ['selected', 'rejected', 'applied'], default: 'applied' },
    driveDate: { type: Date },
    offerLetterUrl: { type: String },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Placement', PlacementSchema);