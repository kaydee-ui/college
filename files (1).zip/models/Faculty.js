const mongoose = require('mongoose');

const FacultySchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        unique: true,
        required: true,
    },
    employeeId: {
        type: String,
        unique: true,
        required: true,
    },
    courses: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Course',
        },
    ],
    dateOfJoining: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Faculty', FacultySchema);