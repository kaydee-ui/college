const mongoose = require('mongoose');

const StudentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        unique: true,
        required: true,
    },
    rollNumber: {
        type: String,
        unique: true,
        required: true,
    },
    courses: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Course',
        },
    ],
    dateOfAdmission: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Student', StudentSchema);