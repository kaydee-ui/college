const mongoose = require('mongoose');

const TimetableSchema = new mongoose.Schema({
    className: { type: String, required: true },
    subject: { type: String, required: true },
    faculty: { type: String },
    day: { type: String, required: true }, // e.g. "Monday"
    startTime: { type: String, required: true }, // e.g. "09:00"
    endTime: { type: String, required: true },   // e.g. "10:00"
    room: { type: String }
});

module.exports = mongoose.model('Timetable', TimetableSchema);