const mongoose = require('mongoose');

const ResultSchema = new mongoose.Schema({
    studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    examId: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    subject: { type: String, required: true },
    marksObtained: { type: Number, required: true },
    totalMarks: { type: Number, required: true },
    grade: { type: String },
    remarks: { type: String }
});

// Prevent duplicate results for the same student, exam, and subject
ResultSchema.index({ studentId: 1, examId: 1, subject: 1 }, { unique: true });

module.exports = mongoose.model('Result', ResultSchema);