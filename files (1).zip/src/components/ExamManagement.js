import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ExamManagement = () => {
    const [exams, setExams] = useState([]);
    const [form, setForm] = useState({
        title: '',
        className: '',
        subject: '',
        examDate: '',
        startTime: '',
        endTime: '',
        room: '',
        totalMarks: ''
    });

    useEffect(() => {
        fetchExams();
    }, []);

    const fetchExams = async () => {
        const res = await axios.get('/api/exams');
        setExams(res.data);
    };

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        await axios.post('/api/exams', { ...form, totalMarks: Number(form.totalMarks) });
        setForm({ title: '', className: '', subject: '', examDate: '', startTime: '', endTime: '', room: '', totalMarks: '' });
        fetchExams();
    };

    const handleDelete = async id => {
        await axios.delete(`/api/exams/${id}`);
        fetchExams();
    };

    return (
        <div>
            <h2>Exam Management</h2>
            <form onSubmit={handleSubmit}>
                <input name="title" value={form.title} onChange={handleChange} placeholder="Exam Title" required />
                <input name="className" value={form.className} onChange={handleChange} placeholder="Class" required />
                <input name="subject" value={form.subject} onChange={handleChange} placeholder="Subject" required />
                <input name="examDate" type="date" value={form.examDate} onChange={handleChange} required />
                <input name="startTime" type="time" value={form.startTime} onChange={handleChange} required />
                <input name="endTime" type="time" value={form.endTime} onChange={handleChange} required />
                <input name="room" value={form.room} onChange={handleChange} placeholder="Room" />
                <input name="totalMarks" type="number" value={form.totalMarks} onChange={handleChange} placeholder="Total Marks" />
                <button type="submit">Add Exam</button>
            </form>
            <table>
                <thead>
                    <tr>
                        <th>Title</th><th>Class</th><th>Subject</th><th>Date</th>
                        <th>Start</th><th>End</th><th>Room</th><th>Marks</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {exams.map(e => (
                        <tr key={e._id}>
                            <td>{e.title}</td>
                            <td>{e.className}</td>
                            <td>{e.subject}</td>
                            <td>{e.examDate?.slice(0,10)}</td>
                            <td>{e.startTime}</td>
                            <td>{e.endTime}</td>
                            <td>{e.room}</td>
                            <td>{e.totalMarks}</td>
                            <td>
                                <button onClick={() => handleDelete(e._id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ExamManagement;