import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AnalyticsDashboard = () => {
    const [summary, setSummary] = useState({});
    const [placements, setPlacements] = useState([]);
    const [booksIssued, setBooksIssued] = useState([]);

    useEffect(() => {
        fetchSummary();
        fetchPlacements();
        fetchBooksIssued();
    }, []);

    const fetchSummary = async () => {
        const res = await axios.get('/api/analytics/summary');
        setSummary(res.data);
    };

    const fetchPlacements = async () => {
        const res = await axios.get('/api/analytics/placements-by-company');
        setPlacements(res.data);
    };

    const fetchBooksIssued = async () => {
        const res = await axios.get('/api/analytics/books-issued');
        setBooksIssued(res.data);
    };

    return (
        <div>
            <h2>Analytics Dashboard</h2>
            <div>
                <h4>Summary</h4>
                <ul>
                    <li>Students: {summary.studentCount}</li>
                    <li>Alumni: {summary.alumniCount}</li>
                    <li>Books: {summary.bookCount}</li>
                    <li>Issued Books: {summary.issuedBooks}</li>
                    <li>Available Books: {summary.availableBooks}</li>
                    <li>Placements: {summary.placementCount}</li>
                </ul>
            </div>
            <div>
                <h4>Placements by Company</h4>
                <ul>
                    {placements.map(item => (
                        <li key={item._id}>{item._id}: {item.count}</li>
                    ))}
                </ul>
            </div>
            <div>
                <h4>Books Issued by Student</h4>
                <ul>
                    {booksIssued.map(item => (
                        <li key={item._id}>{item._id}: {item.issued}</li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default AnalyticsDashboard;