import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ResultsManagement = ({ user }) => {
    const [results, setResults] = useState([]);
    const [form, setForm] = useState({
        studentId: '',
        examId: '',
        subject: '',
        marksObtained: '',
        totalMarks: '',
        remarks: ''
    });
    const [filter, setFilter] = useState({ studentId: '', examId: '' });

    useEffect(() => {
        fetchResults();
        // eslint-disable-next-line
    }, [filter, user]);

    const fetchResults = async () => {
        let endpoint = '/api/results';
        let params = {};
        if (user.role === 'student') {
            endpoint = '/api/results/my';
        } else {
            if (filter.studentId) params.studentId = filter.studentId;
            if (filter.examId) params.examId = filter.examId;
        }
        const res = await axios.get(endpoint, { params });
        setResults(res.data);
    };

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
    const handleFilterChange = e => setFilter({ ...filter, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        await axios.post('/api/results', {
            ...form,
            marksObtained: Number(form.marksObtained),
            totalMarks: Number(form.totalMarks)
        });
        setForm({ studentId: '', examId: '', subject: '', marksObtained: '', totalMarks: '', remarks: '' });
        fetchResults();
    };

    const handleDelete = async id => {
        await axios.delete(`/api/results/${id}`);
        fetchResults();
    };

    const handleExport = async () => {
        const params = {};
        if (filter.studentId) params.studentId = filter.studentId;
        if (filter.examId) params.examId = filter.examId;
        const query = new URLSearchParams(params).toString();
        window.open(`/api/results/export?${query}`, '_blank');
    };

    const calcPercent = (marks, total) => ((marks / total) * 100).toFixed(2);

    return (
        <div>
            <h2>Results / Grades Management</h2>
            {user.role !== 'student' && (
                <form onSubmit={handleSubmit}>
                    <input name="studentId" value={form.studentId} onChange={handleChange} placeholder="Student ID" required />
                    <input name="examId" value={form.examId} onChange={handleChange} placeholder="Exam ID" required />
                    <input name="subject" value={form.subject} onChange={handleChange} placeholder="Subject" required />
                    <input name="marksObtained" type="number" value={form.marksObtained} onChange={handleChange} placeholder="Marks Obtained" required />
                    <input name="totalMarks" type="number" value={form.totalMarks} onChange={handleChange} placeholder="Total Marks" required />
                    <input name="remarks" value={form.remarks} onChange={handleChange} placeholder="Remarks" />
                    <button type="submit">Add Result</button>
                </form>
            )}
            <div style={{margin:"1em 0"}}>
                <strong>Filter:</strong>
                {user.role !== 'student' && (
                    <>
                        <input name="studentId" value={filter.studentId} onChange={handleFilterChange} placeholder="Student ID" />
                        <input name="examId" value={filter.examId} onChange={handleFilterChange} placeholder="Exam ID" />
                        <button onClick={fetchResults}>Apply</button>
                        <button onClick={handleExport}>Export CSV</button>
                    </>
                )}
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Student</th><th>Exam</th><th>Subject</th><th>Marks</th>
                        <th>Total</th><th>%</th><th>Grade</th><th>Remarks</th>
                        {user.role !== 'student' && <th>Action</th>}
                    </tr>
                </thead>
                <tbody>
                    {results.map(r => (
                        <tr key={r._id}>
                            <td>{r.studentId?.name || r.studentId}</td>
                            <td>{r.examId?.title || r.examId}</td>
                            <td>{r.subject}</td>
                            <td>{r.marksObtained}</td>
                            <td>{r.totalMarks}</td>
                            <td>{calcPercent(r.marksObtained, r.totalMarks)}</td>
                            <td>{r.grade}</td>
                            <td>{r.remarks}</td>
                            {user.role !== 'student' && (
                                <td>
                                    <button onClick={() => handleDelete(r._id)}>Delete</button>
                                </td>
                            )}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ResultsManagement;