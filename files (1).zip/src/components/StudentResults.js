import React, { useState, useEffect } from 'react';
import axios from 'axios';

const StudentResults = () => {
    const [results, setResults] = useState([]);

    useEffect(() => {
        const fetchResults = async () => {
            const res = await axios.get('/api/results/my');
            setResults(res.data);
        };
        fetchResults();
    }, []);

    const calcPercent = (marks, total) => ((marks / total) * 100).toFixed(2);

    return (
        <div>
            <h2>My Results</h2>
            <table>
                <thead>
                    <tr>
                        <th>Exam</th><th>Subject</th><th>Marks</th>
                        <th>Total</th><th>%</th><th>Grade</th><th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    {results.map(r => (
                        <tr key={r._id}>
                            <td>{r.examId?.title || r.examId}</td>
                            <td>{r.subject}</td>
                            <td>{r.marksObtained}</td>
                            <td>{r.totalMarks}</td>
                            <td>{calcPercent(r.marksObtained, r.totalMarks)}</td>
                            <td>{r.grade}</td>
                            <td>{r.remarks}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default StudentResults;