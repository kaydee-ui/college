import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TimetableManagement = () => {
    const [entries, setEntries] = useState([]);
    const [form, setForm] = useState({
        className: '',
        subject: '',
        faculty: '',
        day: 'Monday',
        startTime: '',
        endTime: '',
        room: ''
    });

    useEffect(() => {
        fetchEntries();
    }, []);

    const fetchEntries = async () => {
        const res = await axios.get('/api/timetable');
        setEntries(res.data);
    };

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        await axios.post('/api/timetable', form);
        setForm({ className: '', subject: '', faculty: '', day: 'Monday', startTime: '', endTime: '', room: '' });
        fetchEntries();
    };

    const handleDelete = async id => {
        await axios.delete(`/api/timetable/${id}`);
        fetchEntries();
    };

    return (
        <div>
            <h2>Timetable Scheduling</h2>
            <form onSubmit={handleSubmit}>
                <input name="className" value={form.className} onChange={handleChange} placeholder="Class" required />
                <input name="subject" value={form.subject} onChange={handleChange} placeholder="Subject" required />
                <input name="faculty" value={form.faculty} onChange={handleChange} placeholder="Faculty" />
                <select name="day" value={form.day} onChange={handleChange}>
                    {["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"].map(day => (
                        <option key={day} value={day}>{day}</option>
                    ))}
                </select>
                <input name="startTime" type="time" value={form.startTime} onChange={handleChange} required />
                <input name="endTime" type="time" value={form.endTime} onChange={handleChange} required />
                <input name="room" value={form.room} onChange={handleChange} placeholder="Room" />
                <button type="submit">Add Entry</button>
            </form>
            <table>
                <thead>
                    <tr>
                        <th>Class</th><th>Subject</th><th>Faculty</th><th>Day</th>
                        <th>Start</th><th>End</th><th>Room</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {entries.map(e => (
                        <tr key={e._id}>
                            <td>{e.className}</td>
                            <td>{e.subject}</td>
                            <td>{e.faculty}</td>
                            <td>{e.day}</td>
                            <td>{e.startTime}</td>
                            <td>{e.endTime}</td>
                            <td>{e.room}</td>
                            <td>
                                <button onClick={() => handleDelete(e._id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TimetableManagement;