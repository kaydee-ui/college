import React, { useState } from 'react';
import axios from 'axios';

const Login = ({ onLogin }) => {
    const [form, setForm] = useState({ username: '', password: '' });
    const [err, setErr] = useState('');

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            const res = await axios.post('/api/users/login', form);
            localStorage.setItem('token', res.data.token);
            onLogin(res.data.user);
        } catch (error) {
            setErr(error.response?.data?.message || 'Login failed');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input name="username" value={form.username} onChange={handleChange} placeholder="Username" required />
            <input name="password" type="password" value={form.password} onChange={handleChange} placeholder="Password" required />
            <button type="submit">Login</button>
            {err && <div style={{ color: 'red' }}>{err}</div>}
        </form>
    );
};

export default Login;