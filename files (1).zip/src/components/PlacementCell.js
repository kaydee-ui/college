import React, { useEffect, useState } from 'react';
import axios from 'axios';

const PlacementCell = () => {
    const [placements, setPlacements] = useState([]);
    const [formData, setFormData] = useState({
        studentId: '',
        companyName: '',
        position: '',
        salary: '',
        status: 'applied',
        driveDate: '',
        offerLetterUrl: ''
    });

    useEffect(() => {
        fetchPlacements();
    }, []);

    const fetchPlacements = async () => {
        const res = await axios.get('/api/placement');
        setPlacements(res.data);
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('/api/placement', formData);
        setFormData({ studentId: '', companyName: '', position: '', salary: '', status: 'applied', driveDate: '', offerLetterUrl: '' });
        fetchPlacements();
    };

    return (
        <div>
            <h2>Placement Cell</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="studentId" placeholder="Student ID" value={formData.studentId} onChange={handleChange} required />
                <input type="text" name="companyName" placeholder="Company Name" value={formData.companyName} onChange={handleChange} required />
                <input type="text" name="position" placeholder="Position" value={formData.position} onChange={handleChange} required />
                <input type="number" name="salary" placeholder="Salary" value={formData.salary} onChange={handleChange} />
                <select name="status" value={formData.status} onChange={handleChange}>
                    <option value="applied">Applied</option>
                    <option value="selected">Selected</option>
                    <option value="rejected">Rejected</option>
                </select>
                <input type="date" name="driveDate" value={formData.driveDate} onChange={handleChange} />
                <input type="text" name="offerLetterUrl" placeholder="Offer Letter URL" value={formData.offerLetterUrl} onChange={handleChange} />
                <button type="submit">Add Placement</button>
            </form>
            <ul>
                {placements.map((pl) => (
                    <li key={pl._id}>
                        {pl.companyName} - {pl.position} ({pl.status}) | Student: {pl.studentId?.name || pl.studentId}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default PlacementCell;