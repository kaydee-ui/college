import React, { useState, useEffect } from 'react';
import axios from 'axios';

const FeeManagement = () => {
    const [fees, setFees] = useState([]);
    const [form, setForm] = useState({
        studentId: '',
        amount: '',
        dueDate: '',
        remarks: ''
    });

    useEffect(() => {
        fetchFees();
    }, []);

    const fetchFees = async () => {
        const res = await axios.get('/api/fees');
        setFees(res.data);
    };

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        await axios.post('/api/fees', { ...form, amount: Number(form.amount) });
        setForm({ studentId: '', amount: '', dueDate: '', remarks: '' });
        fetchFees();
    };

    const payFee = async id => {
        await axios.put(`/api/fees/${id}/pay`);
        fetchFees();
    };

    return (
        <div>
            <h2>Fee Management</h2>
            <form onSubmit={handleSubmit}>
                <input name="studentId" value={form.studentId} onChange={handleChange} placeholder="Student ID" required />
                <input name="amount" type="number" value={form.amount} onChange={handleChange} placeholder="Amount" required />
                <input name="dueDate" type="date" value={form.dueDate} onChange={handleChange} required />
                <input name="remarks" value={form.remarks} onChange={handleChange} placeholder="Remarks" />
                <button type="submit">Add Fee</button>
            </form>
            <ul>
                {fees.map(fee => (
                    <li key={fee._id}>
                        Student: {fee.studentId?.name || fee.studentId} | Amount: {fee.amount} | Due: {fee.dueDate?.slice(0,10)}
                        {' '}Status: {fee.paid ? 'Paid' : 'Pending'}
                        {!fee.paid && <button onClick={() => payFee(fee._id)}>Mark as Paid</button>}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default FeeManagement;