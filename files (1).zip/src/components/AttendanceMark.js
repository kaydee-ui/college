import React, { useState } from 'react';
import axios from 'axios';

const AttendanceMark = () => {
    const [form, setForm] = useState({
        studentId: '',
        date: '',
        status: 'present',
        subject: '',
        markedBy: '' // You may autofill this with logged-in user id
    });
    const [msg, setMsg] = useState('');

    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            await axios.post('/api/attendance', form);
            setMsg('Attendance marked!');
        } catch (err) {
            setMsg('Error: ' + (err.response?.data?.message || 'Could not mark attendance'));
        }
    };

    return (
        <div>
            <h3>Mark Attendance</h3>
            <form onSubmit={handleSubmit}>
                <input name="studentId" value={form.studentId} onChange={handleChange} placeholder="Student ID" required />
                <input name="date" type="date" value={form.date} onChange={handleChange} required />
                <input name="subject" value={form.subject} onChange={handleChange} placeholder="Subject" />
                <select name="status" value={form.status} onChange={handleChange}>
                    <option value="present">Present</option>
                    <option value="absent">Absent</option>
                    <option value="late">Late</option>
                </select>
                <input name="markedBy" value={form.markedBy} onChange={handleChange} placeholder="Marked By (User ID)" />
                <button type="submit">Mark</button>
            </form>
            {msg && <div>{msg}</div>}
        </div>
    );
};

export default AttendanceMark;