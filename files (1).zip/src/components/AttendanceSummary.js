import React, { useState } from 'react';
import axios from 'axios';

const AttendanceSummary = () => {
    const [subject, setSubject] = useState('');
    const [summary, setSummary] = useState([]);

    const fetchSummary = async () => {
        const res = await axios.get('/api/attendance/summary', { params: { subject } });
        setSummary(res.data);
    };

    return (
        <div>
            <h3>Attendance Summary</h3>
            <input value={subject} onChange={e => setSubject(e.target.value)} placeholder="Subject (optional)" />
            <button onClick={fetchSummary}>Fetch Summary</button>
            <ul>
                {summary.map(item => (
                    <li key={item._id}>{item._id}: {item.count}</li>
                ))}
            </ul>
        </div>
    );
};

export default AttendanceSummary;