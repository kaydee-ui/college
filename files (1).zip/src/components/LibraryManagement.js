import React, { useState, useEffect } from 'react';
import axios from 'axios';

const LibraryManagement = () => {
    const [books, setBooks] = useState([]);
    const [formData, setFormData] = useState({
        title: '',
        author: '',
        ISBN: ''
    });

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        const res = await axios.get('/api/library/books');
        setBooks(res.data);
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('/api/library/books', formData);
        setFormData({ title: '', author: '', ISBN: '' });
        fetchBooks();
    };

    return (
        <div>
            <h2>Library Management</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="title" placeholder="Book Title" value={formData.title} onChange={handleChange} required />
                <input type="text" name="author" placeholder="Author" value={formData.author} onChange={handleChange} required />
                <input type="text" name="ISBN" placeholder="ISBN" value={formData.ISBN} onChange={handleChange} required />
                <button type="submit">Add Book</button>
            </form>
            <ul>
                {books.map((book) => (
                    <li key={book._id}>{book.title} by {book.author} - {book.status}</li>
                ))}
            </ul>
        </div>
    );
};

export default LibraryManagement;