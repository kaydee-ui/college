import React from 'react';

const RoleBasedContent = ({ user }) => {
    if (!user) return null;
    if (user.role === 'admin') return <div>Welcome, Admin! You have full access.</div>;
    if (user.role === 'faculty') return <div>Welcome, Faculty! You can manage courses and students.</div>;
    if (user.role === 'student') return <div>Welcome, Student! You can view your information.</div>;
    return <div>Unknown role.</div>;
};

export default RoleBasedContent;