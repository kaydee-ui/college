import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Notifications = ({ userId }) => {
    const [notifications, setNotifications] = useState([]);
    const [form, setForm] = useState({ title: '', message: '', targetUsers: '' });

    useEffect(() => {
        fetchNotifications();
        // Optionally, poll for new notifications every X seconds
    }, []);

    const fetchNotifications = async () => {
        const res = await axios.get('/api/notifications', { params: { userId } });
        setNotifications(res.data);
    };

    const handleChange = e => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        await axios.post('/api/notifications', {
            ...form,
            targetUsers: form.targetUsers.split(',').map(id => id.trim())
        });
        setForm({ title: '', message: '', targetUsers: '' });
        fetchNotifications();
    };

    const markAsRead = async id => {
        await axios.put(`/api/notifications/${id}/read`);
        fetchNotifications();
    };

    return (
        <div>
            <h2>Notifications</h2>
            <form onSubmit={handleSubmit}>
                <input name="title" value={form.title} onChange={handleChange} placeholder="Title" required />
                <textarea name="message" value={form.message} onChange={handleChange} placeholder="Message" required />
                <input name="targetUsers" value={form.targetUsers} onChange={handleChange} placeholder="Target User IDs (comma separated)" />
                <button type="submit">Send</button>
            </form>
            <ul>
                {notifications.map(n => (
                    <li key={n._id} style={{ fontWeight: n.isRead ? 'normal' : 'bold' }}>
                        <strong>{n.title}</strong>: {n.message}
                        <button disabled={n.isRead} onClick={() => markAsRead(n._id)}>
                            Mark as Read
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Notifications;