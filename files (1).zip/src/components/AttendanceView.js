import React, { useState } from 'react';
import axios from 'axios';

const AttendanceView = () => {
    const [studentId, setStudentId] = useState('');
    const [records, setRecords] = useState([]);

    const fetchAttendance = async () => {
        const res = await axios.get(`/api/attendance/student/${studentId}`);
        setRecords(res.data);
    };

    return (
        <div>
            <h3>View Student Attendance</h3>
            <input value={studentId} onChange={e => setStudentId(e.target.value)} placeholder="Student ID" />
            <button onClick={fetchAttendance}>Fetch</button>
            <ul>
                {records.map(a => (
                    <li key={a._id}>{a.date?.slice(0,10)} - {a.subject || 'N/A'} - {a.status}</li>
                ))}
            </ul>
        </div>
    );
};

export default AttendanceView;