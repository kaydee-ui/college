import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AlumniManagement = () => {
    const [alumni, setAlumni] = useState([]);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        yearOfGraduation: '',
        currentEmployment: '',
        achievements: ''
    });

    useEffect(() => {
        fetchAlumni();
    }, []);

    const fetchAlumni = async () => {
        const res = await axios.get('/api/alumni');
        setAlumni(res.data);
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('/api/alumni', formData);
        setFormData({ name: '', email: '', yearOfGraduation: '', currentEmployment: '', achievements: '' });
        fetchAlumni();
    };

    return (
        <div>
            <h2>Alumni Management</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
                <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
                <input type="number" name="yearOfGraduation" placeholder="Year of Graduation" value={formData.yearOfGraduation} onChange={handleChange} required />
                <input type="text" name="currentEmployment" placeholder="Current Employment" value={formData.currentEmployment} onChange={handleChange} />
                <textarea name="achievements" placeholder="Achievements" value={formData.achievements} onChange={handleChange}></textarea>
                <button type="submit">Add Alumni</button>
            </form>
            <ul>
                {alumni.map((alum) => (
                    <li key={alum._id}>{alum.name} ({alum.yearOfGraduation}) - {alum.currentEmployment}</li>
                ))}
            </ul>
        </div>
    );
};

export default AlumniManagement;