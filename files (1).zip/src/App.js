import React, { useState } from 'react';
import ResultsManagement from './components/ResultsManagement';
import StudentResults from './components/StudentResults';

const mockUser = { role: 'admin' }; // or 'faculty' or 'student'

const App = () => (
    <div>
        <h1>College Management System</h1>
        {mockUser.role === 'student' ? (
            <StudentResults />
        ) : (
            <ResultsManagement user={mockUser} />
        )}
    </div>
);

export default App;