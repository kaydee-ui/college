const express = require('express');
const mongoose = require('mongoose');
const alumniRoutes = require('./routes/alumni');
const libraryRoutes = require('./routes/library');

const app = express();
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost/college-management', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Routes
app.use('/api/alumni', alumniRoutes);
app.use('/api/library', libraryRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));