#!/bin/bash
# Deploy script for your College Management System

set -e

echo "Pulling latest code..."
git pull

echo "Installing backend dependencies..."
cd backend
npm install

echo "Restarting backend with PM2..."
pm2 reload ecosystem.config.json || pm2 start ecosystem.config.json

echo "Building frontend..."
cd ../frontend
npm install
npm run build

echo "Copying frontend build to web root..."
rm -rf /var/www/college-frontend/build
mkdir -p /var/www/college-frontend/build
cp -r build/* /var/www/college-frontend/build/

echo "Reloading NGINX..."
sudo systemctl reload nginx

echo "Deployment complete!"