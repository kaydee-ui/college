import React, { useEffect, useState } from "react";
import axios from "axios";
import "./dashboard.css";

function AdminDashboard() {
  const [students, setStudents] = useState([]);
  const [faculties, setFaculties] = useState([]);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    // Fetch all students
    axios.get("/api/students").then(res => setStudents(res.data));

    // Fetch all faculties
    axios.get("/api/faculties").then(res => setFaculties(res.data));

    // Fetch all courses
    axios.get("/api/courses").then(res => setCourses(res.data));
  }, []);

  return (
    <div className="dashboard-container">
      <h1>Admin Dashboard</h1>
      <div className="dashboard-section">
        <h2>Students</h2>
        <ul>
          {students.map(student => (
            <li key={student._id}>{student.name}</li>
          ))}
        </ul>
      </div>
      <div className="dashboard-section">
        <h2>Faculties</h2>
        <ul>
          {faculties.map(faculty => (
            <li key={faculty._id}>{faculty.name}</li>
          ))}
        </ul>
      </div>
      <div className="dashboard-section">
        <h2>Courses</h2>
        <ul>
          {courses.map(course => (
            <li key={course._id}>{course.name}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default AdminDashboard;