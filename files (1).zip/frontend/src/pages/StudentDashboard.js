import React, { useEffect, useState } from "react";
import axios from "axios";
import "./dashboard.css";

function StudentDashboard() {
  const [courses, setCourses] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [results, setResults] = useState([]);

  useEffect(() => {
    // Fetch enrolled courses
    axios.get("/api/courses?studentId=your-student-id").then(res => setCourses(res.data));

    // Fetch attendance
    axios.get("/api/attendance/student/your-student-id").then(res => setAttendance(res.data));

    // Fetch results
    axios.get("/api/exams/result/student/your-student-id").then(res => setResults(res.data));
  }, []);

  return (
    <div className="dashboard-container">
      <h1>Student Dashboard</h1>
      <div className="dashboard-section">
        <h2>Enrolled Courses</h2>
        <ul>
          {courses.map(course => (
            <li key={course._id}>{course.name}</li>
          ))}
        </ul>
      </div>
      <div className="dashboard-section">
        <h2>Attendance</h2>
        <ul>
          {attendance.map(record => (
            <li key={record._id}>{record.course.name}: {record.status}</li>
          ))}
        </ul>
      </div>
      <div className="dashboard-section">
        <h2>Exam Results</h2>
        <ul>
          {results.map(result => (
            <li key={result._id}>{result.course.name}: {result.grade}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default StudentDashboard;