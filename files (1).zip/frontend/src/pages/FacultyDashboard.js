import React, { useEffect, useState } from "react";
import axios from "axios";
import "./dashboard.css";

function FacultyDashboard() {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    // Fetch all courses assigned to the faculty
    axios.get("/api/courses?facultyId=your-faculty-id").then(res => setCourses(res.data));
  }, []);

  const markAttendance = (courseId) => {
    // Logic to mark attendance for a course
    console.log(`Marking attendance for course ${courseId}`);
  };

  return (
    <div className="dashboard-container">
      <h1>Faculty Dashboard</h1>
      <div className="dashboard-section">
        <h2>Assigned Courses</h2>
        <ul>
          {courses.map(course => (
            <li key={course._id}>
              {course.name} <button onClick={() => markAttendance(course._id)}>Mark Attendance</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default FacultyDashboard;