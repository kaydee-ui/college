const mongoose = require('mongoose');

const FeeSchema = new mongoose.Schema({
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    amount: { type: Number, required: true },
    status: { type: String, enum: ['Paid', 'Pending'], default: 'Pending' },
    dueDate: { type: Date, required: true },
    datePaid: { type: Date },
});

module.exports = mongoose.model('Fee', FeeSchema);