const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, unique: true, required: true },
    faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty' },
    students: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }],
    schedule: { type: String, required: true },
});

module.exports = mongoose.model('Course', CourseSchema);