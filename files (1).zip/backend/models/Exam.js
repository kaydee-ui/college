const mongoose = require('mongoose');

const ExamSchema = new mongoose.Schema({
    course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
    date: { type: Date, required: true },
    time: { type: String, required: true },
    duration: { type: String, required: true },
});

module.exports = mongoose.model('Exam', ExamSchema);