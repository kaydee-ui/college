const express = require('express');
const Faculty = require('../models/Faculty');
const router = express.Router();

// Get all faculties
router.get('/', async (req, res) => {
    try {
        const faculties = await Faculty.find().populate('courses');
        res.json(faculties);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a faculty
router.post('/', async (req, res) => {
    const faculty = new Faculty(req.body);
    try {
        const newFaculty = await faculty.save();
        res.status(201).json(newFaculty);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get a single faculty
router.get('/:id', async (req, res) => {
    try {
        const faculty = await Faculty.findById(req.params.id).populate('courses');
        if (!faculty) return res.status(404).json({ message: 'Faculty not found' });
        res.json(faculty);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update a faculty
router.put('/:id', async (req, res) => {
    try {
        const updatedFaculty = await Faculty.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedFaculty);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a faculty
router.delete('/:id', async (req, res) => {
    try {
        await Faculty.findByIdAndDelete(req.params.id);
        res.json({ message: 'Faculty deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;