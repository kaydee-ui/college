const express = require('express');
const Timetable = require('../models/Timetable');
const router = express.Router();

// Add a timetable entry
router.post('/', async (req, res) => {
    const { course, faculty, day, time } = req.body;
    try {
        const timetable = new Timetable({ course, faculty, day, time });
        await timetable.save();
        res.status(201).json(timetable);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get timetable for a course
router.get('/course/:courseId', async (req, res) => {
    try {
        const timetable = await Timetable.find({ course: req.params.courseId }).populate('faculty course');
        res.json(timetable);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get timetable for a faculty
router.get('/faculty/:facultyId', async (req, res) => {
    try {
        const timetable = await Timetable.find({ faculty: req.params.facultyId }).populate('course');
        res.json(timetable);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;