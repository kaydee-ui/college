const express = require('express');
const Exam = require('../models/Exam');
const Result = require('../models/Result');
const router = express.Router();

// Add an exam
router.post('/exam', async (req, res) => {
    const { course, date, time, duration } = req.body;
    try {
        const exam = new Exam({ course, date, time, duration });
        await exam.save();
        res.status(201).json(exam);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get exams for a course
router.get('/exam/course/:courseId', async (req, res) => {
    try {
        const exams = await Exam.find({ course: req.params.courseId });
        res.json(exams);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a result
router.post('/result', async (req, res) => {
    const { student, course, marks, grade } = req.body;
    try {
        const result = new Result({ student, course, marks, grade });
        await result.save();
        res.status(201).json(result);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get results for a student
router.get('/result/student/:studentId', async (req, res) => {
    try {
        const results = await Result.find({ student: req.params.studentId }).populate('course');
        res.json(results);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;