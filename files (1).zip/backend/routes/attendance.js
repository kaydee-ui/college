const express = require('express');
const Attendance = require('../models/Attendance');
const router = express.Router();

// Mark attendance
router.post('/', async (req, res) => {
    const { student, course, status } = req.body;
    try {
        const attendance = new Attendance({ student, course, status });
        await attendance.save();
        res.status(201).json(attendance);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get attendance by student
router.get('/student/:studentId', async (req, res) => {
    try {
        const attendance = await Attendance.find({ student: req.params.studentId }).populate('course');
        res.json(attendance);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get attendance by course
router.get('/course/:courseId', async (req, res) => {
    try {
        const attendance = await Attendance.find({ course: req.params.courseId }).populate('student');
        res.json(attendance);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;