const express = require('express');
const Fee = require('../models/Fee');
const router = express.Router();

// Get all fees
router.get('/', async (req, res) => {
    try {
        const fees = await Fee.find().populate('student');
        res.json(fees);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a fee record
router.post('/', async (req, res) => {
    const fee = new Fee(req.body);
    try {
        const newFee = await fee.save();
        res.status(201).json(newFee);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update fee payment status
router.put('/:id', async (req, res) => {
    try {
        const updatedFee = await Fee.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedFee);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a fee record
router.delete('/:id', async (req, res) => {
    try {
        await Fee.findByIdAndDelete(req.params.id);
        res.json({ message: 'Fee record deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;